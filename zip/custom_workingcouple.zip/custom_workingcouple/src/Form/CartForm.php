<?php
/**
 * @file
 * Contains \Drupal\student_registration\Form\RegistrationForm.
 */
namespace Drupal\custom_workingcouple\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Stripe\PaymentMethod;
use Stripe\Customer;
use Drupal\commerce_payment\Entity\PaymentMethodInterface;

class CartForm extends FormBase {
  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'cart_form';
  }
  
  public function buildForm(array $form, FormStateInterface $form_state) {

    $form['name'] = array(
      '#type' => 'textfield',
      '#title' => t('Username'),
      '#required' => TRUE,
    );
    $form['email'] = array(
        '#type' => 'textfield',
        '#title' => t('Email ID'),
        '#required' => TRUE,
    );
    $form['cart'] = array(
      '#type' => 'textfield',
      '#title' => t('Cart no.'),
      '#required' => TRUE,
    );

    $form['exp_date'] = array(
        '#type' => 'date',
        '#title' => t('Date'),
        '#required' => TRUE,
    );

    $form['cv'] = array(
    '#type' => 'textfield',
    '#title' => t('CV'),
    '#required' => TRUE,
    );


    $form['actions']['#type'] = 'actions';
    $form['actions']['submit'] = array(
      '#type' => 'submit',
      '#value' => $this->t('Register'),
      '#button_type' => 'primary',
    );
    return $form;
  }
  
  
  public function submitForm(array &$form, FormStateInterface $form_state) {

    $card_number = $form_state->getValue('cart');
    $expiry = $form_state->getValue('exp_date');
    $card_cvv = $form_state->getValue('cv');
    $mail = $form_state->getValue('email');
    $name = $form_state->getValue('name');
    $expiry_date = explode("-", $expiry);

    $today = time();

    $formValues = $form_state->getValues();

    $stripe = new \Stripe\StripeClient(
        'sk_test_51LdSp2SB6w3qfhwfl99z9tj22iSJ8HORVHs4bhU7YBACwGMKAlzROucglw0u9fcwiFSBMDuYgIIds8K7QVZ7hbqq00YgSVB7LR'
    );

    // $products = $stripe->Product->all([]);

    // foreach($products as $product){
    //   $product->prices = \Stripe\Price::all(['product'=>$product->id])->data;
    // }

   
    $stripe_customer_id = $customer->id;


    $payment_method = $stripe->paymentMethods->create([
      'type' => 'card',
      'card' => [
          'number' => $card_number,
          'exp_month' => $expiry_date[1],
          'exp_year' => $expiry_date[0],
          'cvc' => $card_cvv,
      ],
    ]); 
    $customer = $stripe->customers->create([
      "name" => $name,
      "email" => $mail,
      "payment_method" => $payment_method->id
    ]);
    \Drupal::logger('payment_method')->notice('<pre><code>' . print_r($payment_method, TRUE) . '</code></pre>');

    $intent = $stripe->paymentIntents->create([
      'payment_method_types'=>['card'],
      'payment_method' => $payment_method->id,
      'customer' => $customer->id,
      'description' => 'Associate cc with cust for subscription',
      'confirm' => true,
      "amount" => 60,
        "currency" => 'USD',
      // 'usage' => "off_session"
    ]);
    \Drupal::logger('intent')->notice('<pre><code>' . print_r($intent, TRUE) . '</code></pre>');

    $stripe_sub = $stripe->subscriptions->create([
      'customer' => $customer->id,
      'default_payment_method' => $payment_method->id,
      'items' => [
          ['plan' => 'price_1LhptjSB6w3qfhwfrNFk2BbP'],
        ],
    ]);
    \Drupal::logger('stripe_sub')->notice('<pre><code>' . print_r($stripe_sub, TRUE) . '</code></pre>');

    $subscription_id = $stripe_sub->id;
    $subscription_item_id = $stripe_sub->items->data[0]->id;

    $stripe->subscriptions->update($subscription_id,
    [
      'items' => [
       [   'id' => $subscription_item_id,
           'price' => 'price_1LhptjSB6w3qfhwfrNFk2BbP'
       ]
     ]
    ]);
    // $stripe->subscriptions->all([
    //   'customer'=> $customer->id
    // ]);
    
    $invoices = $stripe->invoice->all(['subscription'=> $subscription_id])->data;

    // $charge = $stripe->paymentIntents->create([
    //     "customer" => $customer->id,
    //     "amount" => 1000,
    //     "currency" => 'USD',
    //     "confirm" => true,
    //     "payment_method" => $payment_method->id,
    //     "payment_method_types" => ['card'],
    //     // "return_url" =>   "https://careershifters.biz/processing-stripe-payment/" . $form['#node']->nid . "/one-time?mail=". $formValues['storage']['submitted'][4]
    // ]);
    // \Drupal::logger('charge')->notice('<pre><code>' . print_r($charge, TRUE) . '</code></pre>');
  }
}