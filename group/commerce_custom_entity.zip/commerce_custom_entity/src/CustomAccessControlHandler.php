<?php

namespace Drupal\commerce_custom_entity;

use Drupal\Core\Entity\EntityAccessControlHandler;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Access\AccessResult;

/**
 * Access controller for the commerce_custom_entity entity.
 *
 * @see \Drupal\commerce_custom_entity\Entity\CommerceCustomEntity.
 */
class CustomAccessControlHandler extends EntityAccessControlHandler {

  /**
   * {@inheritdoc}
   */
  protected function checkAccess(EntityInterface $entity, $operation, AccountInterface $account) {
    /** @var \Drupal\commerce_custom_entity\Entity\CommerceCustomEntityInterface $entity */

    switch ($operation) {
      case 'view':
        return AccessResult::allowedIfHasPermission($account, 'view published commerce_custom_entity entities');

      case 'update':
        return AccessResult::allowedIfHasPermission($account, 'edit commerce_custom_entity entities');

      case 'delete':
        return AccessResult::allowedIfHasPermission($account, 'delete commerce_custom_entity entities');
    }

    // Unknown operation, no opinion.
    return AccessResult::neutral();
  }

  /**
   * {@inheritdoc}
   */
  protected function checkCreateAccess(AccountInterface $account, array $context, $entity_bundle = NULL) {
    return AccessResult::allowedIfHasPermission($account, 'add commerce_custom_entity entities');
  }


}
