<?php

namespace Drupal\commerce_custom_entity\Entity;

use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityChangedInterface;
use Drupal\Core\Entity\EntityPublishedInterface;

/**
 * Provides an interface for defining commerce_custom_entity entities.
 *
 * @ingroup commerce_custom_entity
 */
interface CommerceCustomEntityInterface extends ContentEntityInterface, EntityChangedInterface, EntityPublishedInterface {

  /**
   * Add get/set methods for your configuration properties here.
   */

  /**
   * Gets the commerce_custom_entity creation timestamp.
   *
   * @return int
   *   Creation timestamp of the commerce_custom_entity.
   */
  public function getCreatedTime();

  /**
   * Sets the commerce_custom_entity creation timestamp.
   *
   * @param int $timestamp
   *   The commerce_custom_entity creation timestamp.
   *
   * @return \Drupal\commerce_custom_entity\Entity\CommerceCustomEntity
   *   The called commerce_custom_entity entity.
   */
  public function setCreatedTime($timestamp);

}
